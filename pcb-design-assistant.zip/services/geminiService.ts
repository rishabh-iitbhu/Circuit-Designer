import { GoogleGenAI, Type } from "@google/genai";
import type { PCBRequirements, DesignFile } from '../types';

// Fix: Initialize the GoogleGenAI client with a named apiKey parameter from environment variables.
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
const model = 'gemini-2.5-flash';

const requirementsSchema = {
    type: Type.OBJECT,
    properties: {
        projectName: { type: Type.STRING },
        projectSummary: { type: Type.STRING },
        electricalSpecifications: {
            type: Type.OBJECT,
            properties: {
                inputVoltage: { type: Type.STRING },
                outputVoltage: { type: Type.STRING },
                maxCurrentDraw: { type: Type.STRING },
                powerConsumption: { type: Type.STRING },
                efficiencyTarget: { type: Type.STRING },
            },
            required: ['inputVoltage', 'outputVoltage', 'maxCurrentDraw', 'powerConsumption', 'efficiencyTarget']
        },
        keyComponents: {
            type: Type.ARRAY,
            items: { type: Type.STRING }
        },
        communicationInterfaces: {
            type: Type.ARRAY,
            items: { type: Type.STRING }
        },
        physicalConstraints: {
            type: Type.OBJECT,
            properties: {
                dimensions: { type: Type.STRING },
                layers: { type: Type.STRING }
            },
            required: ['dimensions', 'layers']
        },
        environmental: {
            type: Type.OBJECT,
            properties: {
                operatingTemperature: { type: Type.STRING },
                humidity: { type: Type.STRING }
            },
            required: ['operatingTemperature', 'humidity']
        },
        reliability: {
            type: Type.OBJECT,
            properties: {
                estimatedLifespan: { type: Type.STRING }
            },
            required: ['estimatedLifespan']
        }
    },
    required: ['projectName', 'projectSummary', 'electricalSpecifications', 'keyComponents', 'communicationInterfaces', 'physicalConstraints', 'environmental', 'reliability']
};

export const generateRequirementsDoc = async (userInput: string): Promise<PCBRequirements> => {
    const prompt = `Based on the following user description, generate a detailed PCB requirements document in JSON format. The user wants to design a custom PCB. Fill in all the fields of the provided schema as accurately as possible based on the input. Infer reasonable values for any unspecified parameters.

User Description: "${userInput}"

Generate a JSON object that adheres to the provided schema.`;
    try {
        const response = await ai.models.generateContent({
            model: model,
            contents: prompt,
            config: {
                responseMimeType: "application/json",
                responseSchema: requirementsSchema
            }
        });
        
        // Fix: Use the .text property to get the response text.
        const jsonText = response.text;
        return JSON.parse(jsonText) as PCBRequirements;
    } catch (error) {
        console.error("Error generating requirements document:", error);
        throw new Error("Failed to generate requirements from AI. Please check your input and try again.");
    }
};

export const generateCircuitDesignSteps = async (requirements: PCBRequirements): Promise<string[]> => {
    const prompt = `Based on the following PCB requirements, generate a list of 5-7 high-level steps that an AI would take to design the circuit. The steps should be concise, action-oriented, and represent a logical design flow. Output only a JSON array of strings.

Requirements:
${JSON.stringify(requirements, null, 2)}

Example output:
["Component Selection for Core Functionality", "Power Delivery Network Design", "Microcontroller Pin-out and Peripheral Mapping", "Sensor and Interface Circuit Integration", "Layout and Routing Strategy Formulation", "Final Design Rule Check Simulation"]
`;
    try {
        const response = await ai.models.generateContent({
            model: model,
            contents: prompt,
            config: {
                responseMimeType: "application/json",
                responseSchema: {
                    type: Type.ARRAY,
                    items: { type: Type.STRING }
                }
            }
        });

        const jsonText = response.text;
        return JSON.parse(jsonText);
    } catch (error) {
        console.error("Error generating circuit design steps:", error);
        throw new Error("Failed to generate design steps from AI.");
    }
};

export const generateDesignPackage = async (requirements: PCBRequirements): Promise<{ markdownSpec: string; designFiles: DesignFile[] }> => {
    const prompt = `Based on the provided PCB requirements, generate a comprehensive design package. The package must include:
1.  A detailed technical specification document in Markdown format. This document should elaborate on the requirements, detailing component choices, circuit block diagrams, power budget, and layout considerations.
2.  A set of key design files. Generate at least three files:
    - A bill of materials (BOM) in CSV format (e.g., 'bom.csv').
    - A high-level schematic description in pseudo-code or a netlist format (e.g., 'schematic.net').
    - A PCB layout constraints file in a human-readable format (e.g., 'layout.rules').

PCB Requirements:
${JSON.stringify(requirements, null, 2)}

Provide the output as a single JSON object with two keys: "markdownSpec" (containing the Markdown string) and "designFiles" (an array of objects, where each object has "name", "language", and "content" keys).
`;
    try {
        const response = await ai.models.generateContent({
            model: model,
            contents: prompt,
            config: {
                responseMimeType: "application/json",
                responseSchema: {
                    type: Type.OBJECT,
                    properties: {
                        markdownSpec: { type: Type.STRING },
                        designFiles: {
                            type: Type.ARRAY,
                            items: {
                                type: Type.OBJECT,
                                properties: {
                                    name: { type: Type.STRING },
                                    language: { type: Type.STRING },
                                    content: { type: Type.STRING }
                                },
                                required: ['name', 'language', 'content']
                            }
                        }
                    },
                    required: ['markdownSpec', 'designFiles']
                }
            }
        });
        const jsonText = response.text;
        return JSON.parse(jsonText);
    } catch (error) {
        console.error("Error generating design package:", error);
        throw new Error("Failed to generate design package from AI.");
    }
};
