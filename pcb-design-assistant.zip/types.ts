export interface PCBRequirements {
  projectName: string;
  projectSummary: string;
  electricalSpecifications: {
    inputVoltage: string;
    outputVoltage: string;
    maxCurrentDraw: string;
    powerConsumption: string;
    efficiencyTarget: string;
  };
  keyComponents: string[];
  communicationInterfaces: string[];
  physicalConstraints: {
    dimensions: string;
    layers: string;
  };
  environmental: {
    operatingTemperature: string;
    humidity: string;
  };
  reliability: {
    estimatedLifespan: string;
  };
}

// Fix: Add DesignFile interface to be shared across components and services.
export interface DesignFile {
    name: string;
    language: string;
    content: string;
}
