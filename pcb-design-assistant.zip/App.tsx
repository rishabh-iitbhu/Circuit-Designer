import React, { useState } from 'react';
import Stepper from './components/Stepper';
import Step1Requirements from './components/Step1Requirements';
import Step2Simulate from './components/Step2Simulate';
import Step3Specifications from './components/Step3Specifications';
import type { PCBRequirements } from './types';

function App() {
  const [currentStep, setCurrentStep] = useState(1);
  const [pcbRequirements, setPcbRequirements] = useState<PCBRequirements | null>(null);

  const handleRequirementsFinalized = (doc: PCBRequirements) => {
    setPcbRequirements(doc);
    setCurrentStep(2);
  };

  const handleSimulationComplete = () => {
    setCurrentStep(3);
  };

  const handleReset = () => {
      setPcbRequirements(null);
      setCurrentStep(1);
  }

  const renderStepContent = () => {
    switch (currentStep) {
      case 1:
        return <Step1Requirements onFinalize={handleRequirementsFinalized} />;
      case 2:
        return pcbRequirements && <Step2Simulate requirements={pcbRequirements} onComplete={handleSimulationComplete} />;
      case 3:
        return pcbRequirements && <Step3Specifications requirements={pcbRequirements} onReset={handleReset} />;
      default:
        return <Step1Requirements onFinalize={handleRequirementsFinalized} />;
    }
  };

  return (
    <div className="bg-slate-900 min-h-screen text-slate-100 font-sans">
      <main className="container mx-auto px-4 py-8 sm:py-16">
        <header className="text-center mb-12">
          <h1 className="text-4xl sm:text-5xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-blue-500">
            AI PCB Design Assistant
          </h1>
          <p className="mt-4 text-lg text-slate-400 max-w-2xl mx-auto">
            From natural language requirements to a complete design package, powered by Gemini.
          </p>
        </header>

        <Stepper currentStep={currentStep} />
        
        <div className="mt-12 bg-slate-800/50 border border-slate-700 rounded-xl shadow-2xl shadow-slate-900/50 p-6 sm:p-10 backdrop-blur-sm">
          {renderStepContent()}
        </div>
      </main>
      <footer className="text-center py-6 text-slate-500 text-sm">
          <p>&copy; {new Date().getFullYear()} AI PCB Design Assistant. All Rights Reserved.</p>
      </footer>
    </div>
  );
}

export default App;
