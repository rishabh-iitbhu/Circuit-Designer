import React from 'react';

const FileIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    viewBox="0 0 20 20"
    fill="currentColor"
    {...props}
  >
    <path
      fillRule="evenodd"
      d="M4 2a2 2 0 00-2 2v12a2 2 0 002 2h12a2 2 0 002-2V8.414a1 1 0 00-.293-.707l-4.414-4.414A1 1 0 0011.586 2H4zm6 2.5a1.5 1.5 0 011.5 1.5v1.5a1.5 1.5 0 01-3 0V6a1.5 1.5 0 011.5-1.5z"
      clipRule="evenodd"
    />
    <path d="M10 8a.75.75 0 01.75.75v5.5a.75.75 0 01-1.5 0v-5.5A.75.75 0 0110 8z" />
  </svg>
);

export default FileIcon;
