import React, { useState } from 'react';
import { generateRequirementsDoc } from '../services/geminiService';
import type { PCBRequirements } from '../types';
import LoadingSpinner from './LoadingSpinner';
import DocumentDisplay from './DocumentDisplay';

interface Step1RequirementsProps {
  onFinalize: (doc: PCBRequirements) => void;
}

const Step1Requirements: React.FC<Step1RequirementsProps> = ({ onFinalize }) => {
  const [userInput, setUserInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [generatedDoc, setGeneratedDoc] = useState<PCBRequirements | null>(null);

  const handleSubmit = async () => {
    if (!userInput.trim()) {
      setError('Please provide a description of your PCB requirements.');
      return;
    }
    setIsLoading(true);
    setError(null);
    setGeneratedDoc(null);
    try {
      const doc = await generateRequirementsDoc(userInput);
      setGeneratedDoc(doc);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An unknown error occurred.');
    } finally {
      setIsLoading(false);
    }
  };

  const renderGeneratedDoc = () => {
    if (!generatedDoc) return null;
    
    const docString = `# Project: ${generatedDoc.projectName}
## Summary
${generatedDoc.projectSummary}

## Electrical Specifications
- **Input Voltage:** ${generatedDoc.electricalSpecifications.inputVoltage}
- **Output Voltage:** ${generatedDoc.electricalSpecifications.outputVoltage}
- **Max Current Draw:** ${generatedDoc.electricalSpecifications.maxCurrentDraw}
- **Power Consumption:** ${generatedDoc.electricalSpecifications.powerConsumption}
- **Efficiency Target:** ${generatedDoc.electricalSpecifications.efficiencyTarget}

## Key Components
${generatedDoc.keyComponents.map(c => `- ${c}`).join('\n')}

## Communication Interfaces
${generatedDoc.communicationInterfaces.map(i => `- ${i}`).join('\n')}

## Physical Constraints
- **Dimensions:** ${generatedDoc.physicalConstraints.dimensions}
- **Layers:** ${generatedDoc.physicalConstraints.layers}

## Environmental
- **Operating Temperature:** ${generatedDoc.environmental.operatingTemperature}
- **Humidity:** ${generatedDoc.environmental.humidity}

## Reliability
- **Estimated Lifespan:** ${generatedDoc.reliability.estimatedLifespan}
`;

    return (
        <DocumentDisplay title="Generated Requirements Document" content={docString} isMarkdown collapsed/>
    );
  };

  return (
    <div className="flex flex-col gap-6 animate-fade-in-up">
      <div>
        <h2 className="text-2xl font-semibold text-cyan-300">Define Initial Requirements</h2>
        <p className="text-slate-400 mt-2">
          Describe your PCB's purpose, key features, and any known constraints. The more detail you provide, the better the AI-generated requirements will be.
        </p>
      </div>
      
      <textarea
        value={userInput}
        onChange={(e) => setUserInput(e.target.value)}
        placeholder="e.g., I need a small, low-power PCB for a battery-operated weather station. It should use an ESP32, connect to a BME280 sensor for temperature and humidity, and transmit data over Wi-Fi..."
        className="w-full h-40 p-4 bg-slate-900/70 border border-slate-700 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all text-slate-200 placeholder-slate-500"
        disabled={isLoading || !!generatedDoc}
      />

      {error && <p className="text-red-400 bg-red-900/50 p-3 rounded-lg">{error}</p>}
      
      {!generatedDoc && (
         <button
            onClick={handleSubmit}
            disabled={isLoading}
            className="w-full sm:w-auto self-start px-6 py-2.5 bg-blue-600 text-white font-semibold rounded-lg shadow-md hover:bg-blue-700 disabled:bg-slate-600 disabled:cursor-not-allowed transition-all flex items-center justify-center gap-2 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-slate-900 focus:ring-blue-500"
        >
            {isLoading ? <><LoadingSpinner /> Generating...</> : 'Generate Requirements'}
        </button>
      )}

      {isLoading && !generatedDoc && (
        <div className="text-center p-8 flex flex-col items-center justify-center">
            <LoadingSpinner />
            <p className="mt-3 text-slate-400">AI is analyzing your input...</p>
        </div>
      )}

      {generatedDoc && (
        <>
            {renderGeneratedDoc()}
            <div className="flex flex-wrap gap-4 justify-end mt-4">
                 <button
                    onClick={() => {
                        setGeneratedDoc(null);
                        setError(null);
                    }}
                    className="px-6 py-2.5 bg-slate-600 text-white font-semibold rounded-lg shadow-md hover:bg-slate-700 transition-colors focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-slate-900 focus:ring-slate-500"
                >
                    Revise Input
                </button>
                <button
                    onClick={() => onFinalize(generatedDoc)}
                    className="px-6 py-2.5 bg-green-600 text-white font-semibold rounded-lg shadow-md hover:bg-green-700 transition-colors focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-slate-900 focus:ring-green-500"
                >
                    Finalize & Proceed
                </button>
            </div>
        </>
      )}
    </div>
  );
};

export default Step1Requirements;