import React, { useState, useEffect } from 'react';
import type { PCBRequirements } from '../types';
import { generateCircuitDesignSteps } from '../services/geminiService';
import LoadingSpinner from './LoadingSpinner';
import CheckIcon from './icons/CheckIcon';
import CogIcon from './icons/CogIcon';
import CircuitBoard from './CircuitBoard';

interface Step2SimulateProps {
  requirements: PCBRequirements;
  onComplete: () => void;
}

const Step2Simulate: React.FC<Step2SimulateProps> = ({ requirements, onComplete }) => {
    const [steps, setSteps] = useState<string[]>([]);
    const [currentStepIndex, setCurrentStepIndex] = useState(-1);
    const [error, setError] = useState<string | null>(null);
    const [isLoading, setIsLoading] = useState(true);

    useEffect(() => {
        const fetchSteps = async () => {
            setIsLoading(true);
            try {
                const designSteps = await generateCircuitDesignSteps(requirements);
                setSteps(designSteps);
                setCurrentStepIndex(0);
            } catch (err) {
                setError(err instanceof Error ? err.message : 'Failed to get design steps.');
            } finally {
                setIsLoading(false);
            }
        };
        fetchSteps();
    }, [requirements]);

    useEffect(() => {
        if (currentStepIndex >= 0 && currentStepIndex < steps.length) {
            const timer = setTimeout(() => {
                setCurrentStepIndex(currentStepIndex + 1);
            }, 1500 + Math.random() * 500); // Simulate work
            return () => clearTimeout(timer);
        }
    }, [currentStepIndex, steps.length]);

    const isComplete = currentStepIndex >= steps.length;

    return (
        <div className="flex flex-col gap-6 animate-fade-in-up">
            <div className="text-center">
                <h2 className="text-2xl font-semibold text-cyan-300">AI Circuit Design Process</h2>
                <p className="text-slate-400 max-w-3xl mx-auto mt-2">
                    The AI is now performing a high-level circuit design based on the finalized requirements. Watch the process unfold below.
                </p>
            </div>

            {isLoading && (
                <div className="flex flex-col items-center gap-4 p-8">
                    <LoadingSpinner />
                    <p className="text-blue-300">Initializing design process...</p>
                </div>
            )}
            {error && <p className="text-red-400 bg-red-900/50 p-3 rounded-lg text-center">{error}</p>}

            {!isLoading && !error && (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center mt-4">
                    <div className="flex flex-col gap-3">
                        {steps.map((step, index) => {
                            const isStepComplete = index < currentStepIndex;
                            const isStepInProgress = index === currentStepIndex;
                            return (
                                <div key={index} className={`flex items-start gap-4 p-4 rounded-lg transition-all duration-500 ${isStepInProgress ? 'bg-blue-900/50 scale-105 shadow-lg' : 'bg-slate-900/50'} ${isStepComplete ? 'opacity-60' : ''}`}>
                                    <div className="flex-shrink-0 mt-0.5">
                                        {isStepComplete ? (
                                            <div className="w-6 h-6 rounded-full bg-green-500 flex items-center justify-center"><CheckIcon className="w-4 h-4 text-white" /></div>
                                        ) : isStepInProgress ? (
                                             <div className="w-6 h-6 rounded-full bg-blue-500/30 flex items-center justify-center"><CogIcon className="w-4 h-4 text-blue-300 animate-spin" /></div>
                                        ) : (
                                            <div className="w-6 h-6 rounded-full border-2 border-slate-600" />
                                        )}
                                    </div>
                                    <span className={`transition-colors ${isStepComplete ? 'text-slate-400 line-through' : 'text-slate-200'} ${isStepInProgress ? 'text-blue-300 font-semibold' : ''}`}>
                                        {step}
                                    </span>
                                </div>
                            );
                        })}
                    </div>
                    <div className="flex items-center justify-center p-4 h-full">
                        <CircuitBoard completedSteps={currentStepIndex} totalSteps={steps.length} />
                    </div>
                </div>
            )}

            {isComplete && (
                 <div className="flex flex-col items-center gap-4 p-6 bg-green-900/30 border border-green-500/50 rounded-lg mt-6 text-center animate-fade-in-up">
                    <div className="w-12 h-12 rounded-full bg-green-500 flex items-center justify-center shadow-lg shadow-green-500/20">
                        <CheckIcon className="w-8 h-8 text-white"/>
                    </div>
                    <p className="text-xl font-semibold text-green-300">Circuit Design Complete!</p>
                    <p className="text-slate-300">The high-level design is ready for documentation.</p>
                    <button
                        onClick={onComplete}
                        className="px-8 py-2.5 bg-green-600 text-white font-semibold rounded-lg shadow-md hover:bg-green-700 transition-colors focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-slate-900 focus:ring-green-500"
                    >
                        Generate Specification Document
                    </button>
                </div>
            )}
        </div>
    );
};

export default Step2Simulate;