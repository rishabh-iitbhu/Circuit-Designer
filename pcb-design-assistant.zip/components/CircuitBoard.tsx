import React from 'react';

interface CircuitBoardProps {
  completedSteps: number;
  totalSteps: number;
}

// Pre-defined component positions for a visually pleasing layout
const componentPositions = [
  { x: 25, y: 30, w: 30, h: 40, key: 'u1' }, // Microcontroller
  { x: 65, y: 15, w: 15, h: 15, key: 'u2' }, // Sensor
  { x: 10, y: 80, w: 20, h: 8, key: 'j1' },  // Connector
  { x: 65, y: 40, w: 10, h: 10, key: 'pwr' }, // Power management
  { x: 40, y: 80, w: 25, h: 8, key: 'j2' }, // Another connector
  { x: 65, y: 65, w: 15, h: 15, key: 'u3' }, // Peripheral
];

const CircuitBoard: React.FC<CircuitBoardProps> = ({ completedSteps, totalSteps }) => {
  const componentsToShow = Math.min(
    componentPositions.length,
    Math.max(0, completedSteps)
  );

  return (
    <div className="relative w-48 h-48 sm:w-64 sm:h-64">
      <svg viewBox="0 0 100 100" className="w-full h-full shadow-2xl shadow-blue-900/40 rounded-lg">
        {/* Board */}
        <rect width="100" height="100" rx="4" fill="#0f172a" />
        <rect width="96" height="96" x="2" y="2" rx="2" fill="#1e293b" stroke="#38bdf8" strokeWidth="0.5" />
        
        {/* Mounting Holes */}
        <circle cx="5" cy="5" r="2" fill="#0f172a" stroke="#ca8a04" strokeWidth="0.5" />
        <circle cx="95" cy="5" r="2" fill="#0f172a" stroke="#ca8a04" strokeWidth="0.5" />
        <circle cx="5" cy="95" r="2" fill="#0f172a" stroke="#ca8a04" strokeWidth="0.5" />
        <circle cx="95" cy="95" r="2" fill="#0f172a" stroke="#ca8a04" strokeWidth="0.5" />

        {/* Components */}
        {componentPositions.slice(0, componentsToShow).map(({ x, y, w, h, key }) => (
          <g key={key} className="transition-opacity duration-500" style={{ animation: 'component-fade-in 0.5s ease-out' }}>
            <rect 
              x={x} y={y} 
              width={w} height={h} 
              rx="1" 
              fill="#020617" 
              stroke="#475569" 
              strokeWidth="0.75"
            />
          </g>
        ))}
      </svg>
      {/* Add a keyframes style directly since we can't edit a global CSS file */}
      <style>{`
        @keyframes component-fade-in {
          from { opacity: 0; transform: scale(0.8); }
          to { opacity: 1; transform: scale(1); }
        }
      `}</style>
    </div>
  );
};

export default CircuitBoard;