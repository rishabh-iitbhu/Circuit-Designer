import React, { useState } from 'react';
import ClipboardIcon from './icons/ClipboardIcon';
import CheckIcon from './icons/CheckIcon';

interface DocumentDisplayProps {
  title: string;
  content: string;
  isMarkdown?: boolean;
  collapsed?: boolean;
}

const DocumentDisplay: React.FC<DocumentDisplayProps> = ({ title, content, isMarkdown = false, collapsed = false }) => {
  const [isCopied, setIsCopied] = useState(false);
  const [isCollapsed, setIsCollapsed] = useState(collapsed);

  const handleCopy = () => {
    navigator.clipboard.writeText(content);
    setIsCopied(true);
    setTimeout(() => setIsCopied(false), 2000);
  };

  const renderContent = () => {
    if (!isMarkdown) {
        return <pre className="whitespace-pre-wrap font-mono text-sm leading-relaxed">{content}</pre>;
    }
    
    // Improved Regex and processing for Markdown
    let html = content
      .replace(/^### (.*$)/gim, '<h3 class="text-lg font-semibold mt-4 mb-2 text-cyan-200">$1</h3>')
      .replace(/^## (.*$)/gim, '<h2 class="text-xl font-semibold mt-6 mb-3 pb-2 border-b border-slate-700 text-cyan-300">$1</h2>')
      .replace(/^# (.*$)/gim, '<h1 class="text-2xl font-bold mt-8 mb-4 pb-2 border-b border-slate-600 text-cyan-200">$1</h1>')
      .replace(/^\* (.*$)/gim, '<li>$1</li>') // Will be wrapped in <ul>
      .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
      .replace(/`([^`]+)`/g, '<code class="bg-slate-700/50 text-yellow-300 px-1.5 py-1 rounded text-sm font-mono">$1</code>');

    // Wrap list items in <ul>
    html = html.replace(/<li>.*<\/li>/gs, (match) => `<ul>${match}</ul>`);
    // clean up extra ul tags
    html = html.replace(/<\/ul>\s*<ul>/g, '');


    // Process tables
    const tableRegex = /^((?:\|.*\|.*\r?\n)+)/gm;
    html = html.replace(tableRegex, (table) => {
        const rows = table.trim().split('\n');
        if (rows.length < 2 || !rows[1].match(/\|-[-|]+-/)) {
            return table; // Not a valid table
        }
        
        const header = rows[0].split('|').slice(1,-1).map(h => `<th class="p-2 px-3 text-left font-semibold">${h.trim()}</th>`).join('');
        
        const body = rows.slice(2).map(row => {
            const cells = row.split('|').slice(1,-1).map(c => `<td class="p-2 px-3 border-t border-slate-700">${c.trim()}</td>`).join('');
            return `<tr class="hover:bg-slate-800/50">${cells}</tr>`;
        }).join('');
        
        return `<div class="overflow-x-auto my-4"><table class="w-full border-collapse text-sm">
                    <thead class="bg-slate-800"><tr>${header}</tr></thead>
                    <tbody>${body}</tbody>
                </table></div>`;
    });

    return <div className="prose prose-invert prose-sm sm:prose-base max-w-none prose-strong:text-slate-100 prose-headings:tracking-tight" dangerouslySetInnerHTML={{ __html: html }} />;
  };

  return (
    <div className="bg-slate-900/70 border border-slate-700 rounded-lg w-full shadow-inner">
      <div className="flex justify-between items-center p-3 sm:p-4 border-b border-slate-700">
        <h3 className="font-semibold text-slate-300 cursor-pointer" onClick={() => setIsCollapsed(!isCollapsed)}>{title}</h3>
        <div className="flex items-center gap-4">
            <button onClick={() => setIsCollapsed(!isCollapsed)} className="text-sm text-slate-400 hover:text-white transition-colors">{isCollapsed ? 'Expand' : 'Collapse'}</button>
            <button
            onClick={handleCopy}
            className="flex items-center gap-1.5 text-sm text-slate-400 hover:text-white transition-colors disabled:opacity-50"
            disabled={isCopied}
            >
            {isCopied ? <CheckIcon className="w-4 h-4 text-green-400" /> : <ClipboardIcon className="w-4 h-4" />}
            {isCopied ? 'Copied!' : 'Copy'}
            </button>
        </div>
      </div>
      {!isCollapsed && (
        <div className="p-4 sm:p-6 max-h-[60vh] overflow-y-auto">
            {renderContent()}
        </div>
      )}
    </div>
  );
};

export default DocumentDisplay;