import React, { useState, useEffect } from 'react';
import type { PCBRequirements, DesignFile } from '../types';
import { generateDesignPackage } from '../services/geminiService';
import LoadingSpinner from './LoadingSpinner';
import DocumentDisplay from './DocumentDisplay';
import DesignFileViewer from './DesignFileViewer';
import CheckIcon from './icons/CheckIcon';

interface Step3SpecificationsProps {
  requirements: PCBRequirements;
  onReset: () => void;
}

const Step3Specifications: React.FC<Step3SpecificationsProps> = ({ requirements, onReset }) => {
    const [markdownSpec, setMarkdownSpec] = useState<string | null>(null);
    const [designFiles, setDesignFiles] = useState<DesignFile[] | null>(null);
    const [error, setError] = useState<string | null>(null);
    const [isLoading, setIsLoading] = useState(true);

    useEffect(() => {
        const fetchPackage = async () => {
            setIsLoading(true);
            setError(null);
            try {
                const { markdownSpec, designFiles } = await generateDesignPackage(requirements);
                setMarkdownSpec(markdownSpec);
                setDesignFiles(designFiles);
            } catch (err) {
                setError(err instanceof Error ? err.message : 'Failed to generate design package.');
            } finally {
                setIsLoading(false);
            }
        };
        fetchPackage();
    }, [requirements]);

    return (
        <div className="flex flex-col gap-6 animate-fade-in-up">
            <div className="text-center">
                <h2 className="text-2xl font-semibold text-cyan-300">Generated Design Package</h2>
                <p className="text-slate-400 max-w-3xl mx-auto mt-2">
                    The AI has generated a technical specification document and supplementary design files based on your requirements.
                </p>
            </div>
             {isLoading && (
                <div className="flex flex-col items-center gap-4 p-8">
                    <LoadingSpinner />
                    <p className="text-blue-300">Generating final documentation...</p>
                </div>
            )}
            {error && <p className="text-red-400 bg-red-900/50 p-3 rounded-lg text-center">{error}</p>}

            {!isLoading && !error && markdownSpec && designFiles && (
                <>
                    <DocumentDisplay 
                        title="Technical Specification Document"
                        content={markdownSpec}
                        isMarkdown
                    />
                    <DesignFileViewer files={designFiles} />

                     <div className="flex flex-col items-center gap-4 p-6 bg-green-900/30 border border-green-500/50 rounded-lg mt-6 text-center">
                        <div className="w-12 h-12 rounded-full bg-green-500 flex items-center justify-center shadow-lg shadow-green-500/20">
                            <CheckIcon className="w-8 h-8 text-white"/>
                        </div>
                        <p className="text-xl font-semibold text-green-300">Process Complete!</p>
                        <p className="text-slate-300">You can now review and use the generated design assets.</p>
                        <button
                            onClick={onReset}
                            className="px-8 py-2.5 bg-blue-600 text-white font-semibold rounded-lg shadow-md hover:bg-blue-700 transition-colors focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-slate-900 focus:ring-blue-500"
                        >
                            Start New Design
                        </button>
                    </div>
                </>
            )}
        </div>
    );
};

export default Step3Specifications;
