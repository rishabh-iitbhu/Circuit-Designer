import React from 'react';

interface StepperProps {
  currentStep: number;
}

const steps = [
  { number: 1, title: 'Requirements' },
  { number: 2, title: 'Circuit Design' },
  { number: 3, title: 'Design Package' },
];

const Stepper: React.FC<StepperProps> = ({ currentStep }) => {
  return (
    <nav aria-label="Progress">
      <ol role="list" className="flex items-center justify-center">
        {steps.map((step, stepIdx) => (
          <li key={step.title} className={`relative ${stepIdx !== steps.length - 1 ? 'pr-8 sm:pr-20' : ''}`}>
            {step.number < currentStep ? (
              // Completed step
              <>
                <div className="absolute inset-0 flex items-center" aria-hidden="true">
                  <div className="h-0.5 w-full bg-blue-600" />
                </div>
                <div className="relative w-8 h-8 flex items-center justify-center bg-blue-600 rounded-full hover:bg-blue-700">
                    <span className="text-white font-bold">{step.number}</span>
                </div>
              </>
            ) : step.number === currentStep ? (
              // Current step
              <>
                <div className="absolute inset-0 flex items-center" aria-hidden="true">
                  <div className="h-0.5 w-full bg-slate-700" />
                </div>
                <div className="relative w-8 h-8 flex items-center justify-center bg-slate-800 border-2 border-blue-500 rounded-full" aria-current="step">
                  <span className="text-blue-400 font-bold">{step.number}</span>
                </div>
                <span className="absolute -bottom-7 w-max -left-1/2 ml-4 text-sm font-medium text-blue-400">{step.title}</span>
              </>
            ) : (
              // Upcoming step
              <>
                <div className="absolute inset-0 flex items-center" aria-hidden="true">
                  <div className="h-0.5 w-full bg-slate-700" />
                </div>
                <div className="group relative w-8 h-8 flex items-center justify-center bg-slate-800 border-2 border-slate-600 rounded-full">
                   <span className="text-slate-400">{step.number}</span>
                </div>
              </>
            )}
          </li>
        ))}
      </ol>
    </nav>
  );
};

export default Stepper;
