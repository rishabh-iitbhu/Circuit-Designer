import React, { useState } from 'react';
import type { DesignFile } from '../types';
import DocumentDisplay from './DocumentDisplay';
import FileIcon from './icons/FileIcon';
import ImageIcon from './icons/ImageIcon';

interface DesignFileViewerProps {
  files: DesignFile[];
}

const getIconForFile = (fileName: string) => {
    const extension = fileName.split('.').pop()?.toLowerCase();
    switch(extension) {
        case 'png':
        case 'jpg':
        case 'jpeg':
        case 'svg':
            return <ImageIcon className="w-5 h-5 text-purple-400" />;
        default:
            return <FileIcon className="w-5 h-5 text-slate-400" />;
    }
}

const DesignFileViewer: React.FC<DesignFileViewerProps> = ({ files }) => {
  const [selectedFile, setSelectedFile] = useState<DesignFile | null>(files[0] || null);

  if (!files || files.length === 0) {
    return null;
  }

  return (
    <div className="flex flex-col md:flex-row gap-4 bg-slate-900/70 border border-slate-700 rounded-lg shadow-inner overflow-hidden">
      <aside className="w-full md:w-1/4 lg:w-1/5 border-b md:border-b-0 md:border-r border-slate-700 p-3">
        <h4 className="font-semibold text-slate-300 mb-3 px-2">Design Files</h4>
        <ul className="flex flex-row md:flex-col gap-1 overflow-x-auto pb-2 md:pb-0">
          {files.map((file) => (
            <li key={file.name}>
              <button
                onClick={() => setSelectedFile(file)}
                className={`w-full flex items-center gap-3 text-left p-2 rounded-md transition-colors text-sm ${
                  selectedFile?.name === file.name
                    ? 'bg-blue-600/30 text-blue-300'
                    : 'text-slate-300 hover:bg-slate-700/50'
                }`}
              >
                <span className="flex-shrink-0">{getIconForFile(file.name)}</span>
                <span className="truncate flex-grow">{file.name}</span>
              </button>
            </li>
          ))}
        </ul>
      </aside>
      <main className="flex-1 p-0 sm:p-2 min-h-[300px]">
        {selectedFile && (
          <DocumentDisplay
            title={selectedFile.name}
            content={selectedFile.content}
            isMarkdown={selectedFile.language.toLowerCase() === 'markdown'}
          />
        )}
      </main>
    </div>
  );
};

export default DesignFileViewer;
